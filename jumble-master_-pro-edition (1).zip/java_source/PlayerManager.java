public class PlayerManager {
    private String name;
    private String message;

    public void savePlayer(String name, String message) {
        this.name = name;
        this.message = message;
    }

    public String getName() {
        return name;
    }

    public String getMessage() {
        return message;
    }
}
