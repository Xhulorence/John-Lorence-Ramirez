/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Gamepad2, UserCog, User } from 'lucide-react';
import { motion } from 'motion/react';
import React from 'react';
import { Button } from './UI';

interface MenuPageProps {
  onSelectAdmin: () => void;
  onSelectPlayer: () => void;
}

export const MenuPage: React.FC<MenuPageProps> = ({ onSelectAdmin, onSelectPlayer }) => {
  return (
    <div className="flex flex-col items-center justify-center h-full w-full text-center p-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-12"
      >
        <div className="flex justify-center mb-6">
          <div className="p-6 bg-indigo-600 rounded-[2.5rem] shadow-[0_0_50px_rgba(79,70,229,0.3)]">
            <Gamepad2 size={64} className="text-white" />
          </div>
        </div>
        <h1 className="text-7xl md:text-[120px] font-black text-white tracking-tighter uppercase leading-none mb-4 flex items-center justify-center">
          JUMBLE<span className="text-[#6366f1]">PRO</span>
        </h1>
        <p className="text-slate-500 text-sm md:text-base font-black uppercase tracking-[0.6em] opacity-80">
          Strategic Word Decryption Terminal
        </p>
      </motion.div>

      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.3 }}
        className="flex flex-col md:flex-row gap-8 w-full max-w-4xl px-4"
      >
        <button
          id="admin_button"
          onClick={onSelectAdmin}
          className="flex-1 group h-48 md:h-64 bg-[#1e293b] hover:bg-[#202d41] border border-slate-700/50 rounded-[2rem] transition-all relative overflow-hidden flex flex-col items-center justify-center gap-6 shadow-2xl"
        >
          <div className="p-4 bg-slate-900/50 rounded-2xl group-hover:bg-slate-800 transition-colors">
            <UserCog size={48} className="text-slate-400 group-hover:text-white transition-colors" />
          </div>
          <span className="text-xl font-black tracking-widest text-white uppercase italic">ADMIN PORTAL</span>
        </button>

        <button
          id="player_button"
          onClick={onSelectPlayer}
          className="flex-1 group h-48 md:h-64 bg-[#6366f1] hover:bg-[#585af2] rounded-[2rem] transition-all relative overflow-hidden flex flex-col items-center justify-center gap-6 shadow-[0_0_60px_rgba(99,102,241,0.2)]"
        >
          <div className="p-4 bg-white/10 rounded-2xl group-hover:bg-white/20 transition-colors">
            <User size={48} className="text-white" />
          </div>
          <span className="text-xl font-black tracking-widest text-white uppercase italic">START SESSION</span>
          <div className="absolute inset-0 bg-white/5 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none" />
        </button>
      </motion.div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.6 }}
        className="absolute bottom-12 text-slate-600 text-[10px] font-black tracking-[0.5em] uppercase"
      >
        CORE SYSTEM ONLINE • BUILD v2.4.0
      </motion.div>
    </div>
  );
};
