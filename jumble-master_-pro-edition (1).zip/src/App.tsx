/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { AnimatePresence, motion } from 'motion/react';
import { useState } from 'react';
import { AdminLoginPage } from './components/AdminLoginPage';
import { AdminPage } from './components/AdminPage';
import { GamePage } from './components/GamePage';
import { MenuPage } from './components/MenuPage';
import { PlayerInfoPage } from './components/PlayerInfoPage';
import { ResultPage } from './components/ResultPage';
import { StartPage } from './components/StartPage';

type ViewState = 'menu' | 'admin-login' | 'admin-dashboard' | 'player-info' | 'start-page' | 'game-page' | 'result-page';

export default function App() {
  const [view, setView] = useState<ViewState>('menu');
  const [finalResult, setFinalResult] = useState<{ score: number; time: number } | null>(null);

  const handleWin = (score: number, timeSpent: number) => {
    setFinalResult({ score, time: timeSpent });
    setView('result-page');
  };

  const renderView = () => {
    switch (view) {
      case 'menu':
        return <MenuPage onSelectAdmin={() => setView('admin-login')} onSelectPlayer={() => setView('player-info')} />;
      case 'admin-login':
        return <AdminLoginPage onLogin={() => setView('admin-dashboard')} onBack={() => setView('menu')} />;
      case 'admin-dashboard':
        return <AdminPage onBack={() => setView('menu')} />;
      case 'player-info':
        return <PlayerInfoPage onContinue={() => setView('start-page')} onBack={() => setView('menu')} />;
      case 'start-page':
        return <StartPage onStart={() => setView('game-page')} onBack={() => setView('player-info')} />;
      case 'game-page':
        return <GamePage onWin={handleWin} onExit={() => setView('menu')} />;
      case 'result-page':
        return (
          <ResultPage 
            score={finalResult?.score || 0} 
            timeSpent={finalResult?.time || 0} 
            onPlayAgain={() => setView('game-page')} 
            onMenu={() => setView('menu')} 
          />
        );
      default:
        return <MenuPage onSelectAdmin={() => setView('admin-login')} onSelectPlayer={() => setView('player-info')} />;
    }
  };

  return (
    <div className="h-screen bg-slate-950 text-slate-50 font-sans flex flex-col overflow-hidden select-none border-8 border-slate-900 selection:bg-indigo-500 selection:text-white">
      {/* Top Navigation Bar */}
      <nav className="h-16 w-full bg-black flex items-center justify-between px-8 border-b border-slate-900 shrink-0">
        <div className="flex items-center gap-4">
          <div className="w-8 h-8 bg-[#6366f1] rounded-md flex items-center justify-center font-black text-xl shadow-[0_0_20px_rgba(99,102,241,0.4)]">J</div>
          <span className="font-black tracking-tighter text-2xl uppercase text-white flex items-center">
            JUMBLE<span className="text-[#6366f1] font-light ml-1 opacity-80">PRO</span>
          </span>
        </div>
        <div className="flex gap-10 items-center text-[11px] font-black text-slate-400 tracking-[0.15em]">
          <span className={`${view === 'game-page' ? 'text-[#6366f1]' : 'hover:text-slate-200 cursor-pointer'} transition-all`} onClick={() => view !== 'game-page' && setView('menu')}>GAMEPLAY</span>
          <span className={`${view === 'admin-dashboard' ? 'text-[#6366f1]' : 'hover:text-slate-200 cursor-pointer'} transition-all`} onClick={() => setView('admin-login')}>ADMIN PORTAL</span>
          <div className="h-4 w-[1px] bg-slate-800 opacity-50"></div>
          <button className="hover:text-white transition-colors uppercase" onClick={() => window.close()}>Exit Application</button>
        </div>
      </nav>

      <main className="flex-grow flex overflow-hidden relative justify-center items-center bg-[#05060f]">
        <AnimatePresence mode="wait">
          <motion.div
            key={view}
            initial={{ opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 1.01 }}
            transition={{ duration: 0.25, ease: 'easeOut' }}
            className="w-full h-full flex items-center justify-center overflow-hidden"
          >
            {renderView()}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* Bottom Bar */}
      <footer className="h-12 w-full bg-[#6366f1] flex items-center px-8 justify-between text-[10px] font-black shrink-0 text-white shadow-[0_-10px_30px_rgba(0,0,0,0.3)]">
        <div className="flex items-center gap-6">
          <span className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-white shadow-[0_0_10px_white]"></div> 
            SYSTEM STATUS: OPTIMAL
          </span>
          <span className="text-white/60 tracking-widest uppercase font-bold">Encryption Mode: Active</span>
        </div>
        <div className="flex gap-10 tracking-[0.2em] items-center">
          <span className="text-white/80">BUILD v2.4.0 (CODENAME: BOLD)</span>
          <button className="hover:text-black/80 transition-colors uppercase bg-black/10 px-3 py-1 rounded-md" onClick={() => setView('menu')}>Reset Session</button>
        </div>
      </footer>
    </div>
  );
}

